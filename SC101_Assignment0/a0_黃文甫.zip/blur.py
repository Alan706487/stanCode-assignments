"""
File: blur.py
Name:
-------------------------------
This file shows the original image first,
smiley-face.png, and then compare to its
blurred image. The blur algorithm uses the
average RGB values of a pixel's nearest neighbors.
"""

from simpleimage import SimpleImage

# 圖寬300 長300
def blur(img):
    """
    :param img:
    :return:
    """
    from simpleimage import SimpleImage
    new_img = SimpleImage.blank(1, 1)
    for x in range(img.width):
        for y in range(img.height):
            pixel = img.get_pixel(x, y)
            if x != 0:
                pixel_left = img.get_pixel(x-1, y)
            else:
                pixel_left = new_img.get_pixel(0, 0)
            if x !=300:
                pixel_right = img.get_pixel(x+1, y)
            else:
                pixel_right = new_img.get_pixel(0, 0)
            if y != 300:
                pixel_up = img.get_pixel(x, y+1)
            else:
                pixel_up = new_img.get_pixel(0, 0)
            if y != 0:
                pixel_down = img.get_pixel(x, y-1)
            else:
                pixel_down = new_img.get_pixel(0, 0)
            if x != 0 and y != 300:
                pixel_leftup = img.get_pixel(x-1, y+1)
            else:
                pixel_leftup = new_img.get_pixel(0, 0)
            if x != 0 and y != 300:
                pixel_leftdown = img.get_pixel(x-1, y-1)
            else:
                pixel_leftdown = new_img.get_pixel(0, 0)
            if x != 300 and y !=300:
                pixel_rightup = img.get_pixel(x+1, y+1)
            else:
                pixel_rightup = new_img.get_pixel(0, 0)
            if x != 300 and y != 0:
                pixel_rightdown = img.get_pixel(x+1, y-1)
            else:
                pixel_rightdown = new_img.get_pixel(0, 0)

            if x == 0 and y == 0:
                pixel.red = (pixel_right.red + pixel_rightdown.red + pixel_down.red) / 3
                pixel.green = (pixel_right.green + pixel_rightdown.green + pixel_down.green) / 3
                pixel.blue = (pixel_right.blue + pixel_rightdown.blue + pixel_down.blue) / 3

            elif x == 300 and y == 0:
                pixel.red = (pixel_right.red + pixel_rightup.red + pixel_up.red) / 3
                pixel.green = (pixel_right.green + pixel_rightup.green + pixel_up.green) / 3
                pixel.blue = (pixel_right.blue + pixel_rightup.blue + pixel_up.blue) / 3

            elif x == 0 and y == 300:
                pixel.red = (pixel_left.red + pixel_leftdown.red + pixel_down.red) / 3
                pixel.green = (pixel_left.green + pixel_leftdown.green + pixel_down.green) / 3
                pixel.blue = (pixel_left.blue + pixel_leftdown.blue + pixel_down.blue) / 3

            elif x == 300 and y == 300:
                pixel.red = (pixel_left.red + pixel_leftup.red + pixel_up.red) / 3
                pixel.green = (pixel_left.green + pixel_leftup.green + pixel_up.green) / 3
                pixel.blue = (pixel_left.blue + pixel_leftup.blue + pixel_up.blue) / 3

            elif x == 0:
                pixel.red = (pixel_left.red + pixel_leftdown.red + pixel_down.red + pixel_rightdown.red + pixel_right.red) / 5
                pixel.green = (pixel_left.green + pixel_leftdown.green + pixel_down.green + pixel_rightdown.green + pixel_right.green) / 5
                pixel.blue = (pixel_left.blue + pixel_leftdown.blue + pixel_down.blue + pixel_rightdown.blue + pixel_right.blue) / 5

            elif x == 300:
                pixel.red = ( pixel_left.red + pixel_leftup.red + pixel_up.red + pixel_rightup.red + pixel_right.red) / 5
                pixel.green = (pixel_left.green + pixel_leftup.green + pixel_up.green + pixel_rightup.green + pixel_right.green) / 5
                pixel.blue = (pixel_left.blue + pixel_leftup.blue + pixel_up.blue + pixel_rightup.blue + pixel_right.blue) / 5

            elif y == 0:
                pixel.red = (pixel_up.red + pixel_rightup.red + pixel_right.red + pixel_rightdown.red + pixel_down.red) / 5
                pixel.green = (pixel_up.green + pixel_rightup.green + pixel_right.green + pixel_rightdown.green + pixel_down.green) / 5
                pixel.blue = (pixel_up.blue + pixel_rightup.blue + pixel_right.blue + pixel_rightdown.blue + pixel_down.blue) / 5

            elif y == 300:
                pixel.red = (pixel_up.red + pixel_leftup.red + pixel_left.red + pixel_leftdown.red + pixel_down.red) / 5
                pixel.green = (pixel_up.green + pixel_leftup.green + pixel_left.green + pixel_leftdown.green + pixel_down.green) / 5
                pixel.blue = (pixel_up.blue + pixel_leftup.blue + pixel_left.blue + pixel_leftdown.blue + pixel_down.blue) / 5

            else:
                pixel.red = (pixel_left.red + pixel_leftdown.red + pixel_down.red + pixel_rightdown.red + pixel_right.red + pixel_rightup.red + pixel_up.red + pixel_leftup.red) / 5
                pixel.green = (pixel_left.green + pixel_leftdown.green + pixel_down.green + pixel_rightdown.green + pixel_right.green + pixel_rightup.green + pixel_up.green + pixel_leftup.green) / 5
                pixel.blue = (pixel_left.blue + pixel_leftdown.blue + pixel_down.blue + pixel_rightdown.blue + pixel_right.blue + pixel_rightup.blue + pixel_up.blue + pixel_leftup.blue) / 5
                return new_img

def main():
    """
    TODO:
    """

    old_img = SimpleImage("images/smiley-face.png")
    old_img.show()
    blurred_img = blur(old_img)
    for i in range(5):
        blurred_img = blur(blurred_img)
    blurred_img.show()


# ---- DO NOT EDIT CODE BELOW THIS LINE ---- #

if __name__ == '__main__':
    main()

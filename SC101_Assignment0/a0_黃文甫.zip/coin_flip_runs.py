"""
File: coin_flip_runs.py
Name:
-----------------------
This program should simulate coin flip(s)
with the number of runs input by users.
A 'run' is defined as consecutive results
on either 'H' or 'T'. For example, 'HHHHHTHTT'
is regarded as a 2-run result.
Your program should stop immediately after your
coin flip results reach the number of runs!
"""

import random as rd


def main():
	"""
	翻硬幣
	"""
	print("Let's flip a coin! ")
	num_run = 0 #輸入的(重複數次數)每次都清零
	num_run = int(input("Number of runs: "))

	count = 0
	x = 'begin'
	y = 'begin'
	rep = 0  # 重複出現數
	while count != num_run:
		y = x
		x = rd.randrange(2)

		if x == 0:
			x = 'T'
		else:
			x = 'H'
		print(x, end='')

		if y == x:
			rep += 1
			if rep >> 1:
				continue
			count += 1
		else:
			rep = 0


# ---- DO NOT EDIT CODE BELOW THIS LINE ---- #

if __name__ == "__main__":
	main()

"""
File: class_reviews.py
Name:
-------------------------------
At the beginning of this program, the user is asked to input
the class name (either SC001 or SC101).
Attention: your input should be case-insensitive.
If the user input "-1" for class name, your program would show
the maximum, minimum, and average among all the inputs.
"""


def main():
    """
    TODO: 期末評分計算程式!
    假設輸入分數為非零整數
    """
    sc001_max = 0
    sc001_min = 0
    sc001_total = 0 #儲存輸入的總分
    sc001_len = 0 #儲存輸入次數

    sc101_max = 0
    sc101_min = 0
    sc101_total = 0
    sc101_len = 0

    cl = "" #儲存輸入班級 一開始為空格
    sc = "" #儲存輸入分數 一開始為空格

    while cl != "-1": #一開始為空格 所以皆會執行

        cl = input("Which class? ")
        if cl == "-1" and (sc001_total or sc101_total) != 0: #cl輸入-1且非首次輸入分數(001或101有分數)時執行

            print("{:=^50s}".format("SC001"))
            if sc001_total == 0:
                print("No score for SC001")
            else:
                print(f'Max (001): {sc001_max}')
                print(f'Min (001): {sc001_min}')
                print(f'Avg (001): {sc001_total / sc001_len}') #總分除以次數即為平均
            print("{:=^50s}".format("SC101"))
            if sc101_total == 0:
                print("No score for SC101")
            else:
                print(f'Max (101): {sc101_max}')
                print(f'Min (101): {sc101_min}')
                print(f'Avg (101): {sc101_total / sc101_len}')

        elif cl == "-1" and sc001_total == 0 and sc101_total == 0: #cl輸入-1且首次輸入分數(001和101皆無分數)時執行
            print("No class scores were entered")
            break #跳出while迴圈
        else:  #cl非輸入-1時執行
            sc = int(input("Score: ")) #用sc儲存輸入的分數

        #分類輸入的分數屬於哪班
        if cl.lower() == 'sc001':
            sc001_total += sc
            sc001_len += 1
            if sc >= sc001_max: #輸入分數大於前值時 取代為最大值 (一開始sc001_max = 0 必取代)
                sc001_max = sc

            if sc <= sc001_min:
                sc001_min = sc

            if sc001_len == 1: #只輸入一筆分數時 最小值為輸入分數
                sc001_min = sc



        else:
            sc101_total += sc
            sc101_len += 1
            if sc >= sc101_max:
                sc101_max = sc
            if sc <= sc101_min:
                sc101_min = sc
            if sc101_len == 1:
                sc101_min = sc


# ---- DO NOT EDIT CODE BELOW THIS LINE ---- #

if __name__ == '__main__':
    main()
